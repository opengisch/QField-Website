---
title: "{{ replace .Name "-" " " | title }}"
description: ""
draft: true
tags: ["featured"]
images: ["{{ .Name | urlize }}.jpg"]
keywords: ["{{ replace .Name "-" " " | lower }}"]
---

# {{ replace .Name "-" " " | title }}

{{< img src="{{ .Name | urlize }}.jpg" alt="{{ replace .Name "-" " " | title }}" caption="{{ replace .Name "-" " " | title }}" class="wide" >}}
