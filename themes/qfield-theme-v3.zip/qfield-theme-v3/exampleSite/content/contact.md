---
title: "Contact"
draft: false
menu:
  main:
    weight: 90
---

# Contact

[Open an issue](https://github.com/filipecarneiro/hugo-bootstrap-theme/issues/new) on GitHub.
